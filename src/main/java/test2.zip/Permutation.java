import edu.princeton.cs.algs4.StdIn;

import edu.princeton.cs.algs4.StdOut;

import edu.princeton.cs.algs4.StdRandom;

/******************************************************************************
 * 
 * Name: Kevin Wayne Login: wayne Precept: P02
 *
 * 
 * 
 * Partner Name: N/A Partner Login: N/A Partner Precept: N/A
 * 
 * 
 * 
 * Compilation: javac-algs4 Permutation.java Execution: java-algs4 Permutation k
 * 
 * < <filename> Dependencies: RandomizedQueue.java StdIn.java StdOut.java
 *
 * 
 * 
 * Description: Takes an integer k as a command-line argument; reads in a
 * 
 * sequence of strings from standard input using StdIn.readString(); and prints
 * 
 * exactly k of them, uniformly at random. Prints each item from the sequence at
 * 
 * most once.
 * 
 ******************************************************************************/

public class Permutation {

	public static void main(String[] args) {
		int k = Integer.parseInt(args[0]);
		int count = 0;
		RandomizedQueue<String> rQueue = new RandomizedQueue<String>();
		while (!StdIn.isEmpty()) {
			String item = StdIn.readString();
			count++;
			if (rQueue.size() < k) {
				rQueue.enqueue(item);
			} else if (StdRandom.uniform() < (double) k / count) {
				rQueue.dequeue();
				rQueue.enqueue(item);
			}
		}
		for (String item : rQueue) {
			System.out.println(item);
		}
	}

}